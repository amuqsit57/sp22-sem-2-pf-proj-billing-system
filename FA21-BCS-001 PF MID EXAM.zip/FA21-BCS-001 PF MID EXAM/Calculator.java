import javax.swing.border.TitledBorder;
import javax.swing.border.Border;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
//import Buttons.*;

public class Calculator implements ActionListener {

		JFrame frame = new JFrame();	//creating an object of the class JFrame
		JLabel label = new JLabel();	//creating an object of the class JLabel
		JButton[] numberButton= new JButton[10];	//creating an array of object of the class JButton
		JButton[] functionButton=new JButton[25];
		JButton[] dTypeButton = new JButton[6];
		JTextField textfield;

		JButton addButton , multiButton, subtButton, diviButton;
		JButton decButton, equalButton, deletButton, clearButton;
		JButton remButton, percButton, expButton, degButton, radButton, miscButton;
		JButton sinButton, cosButton, tanButton, invButton, hypButton,logButton;
		JButton intButton, fltButton, bytButton, shtButton, lngButton,dblButton;



		JPanel panel, panel1, panel2, panel3;
		
		//mode buttons
		JButton dec, hexa, octal, binary;

		//Alphabets buttons
		JButton  a , b ,c, d ,e;

		Font myFont = new Font("Times New Roman",Font.BOLD,10);
		Font myFont2 = new Font("Times New Roman",Font.BOLD,15);
		Font myFont3 = new Font("Times New Roman",Font.BOLD,25);
		Font myFont4 = new Font("Times New Roman",Font.BOLD,8);
		int num1ForInt=0,num2ForInt=0,resultForInt=0;
		long num1ForLong=0,num2ForLong=0,resultForLong=0;
		byte num1ForByte=0,num2ForByte=0,resultForByte=0;
		short num1ForShort=0,num2ForShort=0,resultForShort=0;
		float num1ForFloat=0,num2ForFloat=0,resultForFloat=0;
		double num1ForDouble=0,num2ForDouble=0,resultForDouble=0;

		//for hexa mode
		String num1forHexa="0" ;String num2forHexa="0" ; String resultforHexa="0" ; 
		int subtHexa; int diff=0 ;
		
		//for octal mode
		String num1forOct="0" ;String num2forOct="0" ; String resultforOct="0" ; 
		int subtOct; int diff1=0 ;
		
		//for binary mode
		String num1forBin="0" ;String num2forBin="0" ; String resultforBin="0" ; 
		int subtBin; int diff2=0 ;
		char operator;
		
		String trig; double modifiedTrig=0; final double PI=3.1421;
		

		Calculator(){		//adding an constructor which is called upon creation of the object of the class
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(550,580);
			frame.setResizable(false);
			frame.setLayout(null);
			frame.setTitle("CALCULATOR");
			frame.getContentPane().setBackground(Color.WHITE);
			
			panel3 = new JPanel();
			panel3.setBackground(new Color(245,245,245));
			panel3.setBounds(120,10,270,500);
			Border blackline = BorderFactory.createLineBorder(new Color(0,0,0,8),4);
			panel3.setBorder(blackline);
		
			
			textfield = new JTextField();
			textfield.setBounds(140,50,230,50);
			textfield.setEditable(false);
			textfield.setBackground(new Color(255, 255, 255));
			textfield.setFont(myFont3);
		

			//creating data type buttons

			intButton = new JButton("int");
			shtButton = new JButton("byte");
			lngButton = new JButton("Short");
			bytButton = new JButton("Long");
			fltButton = new JButton("Float");
			dblButton = new JButton("Dble");

			dTypeButton[0]= intButton;
			dTypeButton[1]= bytButton;
			dTypeButton[2]= shtButton;
			dTypeButton[3]= lngButton;
			dTypeButton[4]= fltButton;
			dTypeButton[5]= dblButton;

			
	
			//creating the mode buttons
			dec = new JButton("DEC");
			hexa = new JButton("HEXA");
			octal = new JButton("OCT");
			binary = new JButton("BIN");
		
			dec.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0){
					dec.setEnabled(false);
					for(int i = 8 ; i < 13; i++){
						functionButton[i].setEnabled(false);
					}
					for(int i = 13 ; i < functionButton.length; i++){
						functionButton[i].setEnabled(true);
					}

					//setting all the other the other things to true
					for(int i = 0 ; i < numberButton.length ; i++){
						numberButton[i].setEnabled(true);
					}
					hexa.setEnabled(true);
					octal.setEnabled(true);	
					binary.setEnabled(true);	
					//giving every datatype button default positions
					dTypeButton[0].setEnabled(true);
					dTypeButton[1].setEnabled(true);
					dTypeButton[2].setEnabled(true);
					dTypeButton[3].setEnabled(true);
					dTypeButton[4].setEnabled(true);
					dTypeButton[5].setEnabled(true);
								
				}
			});

			dec.setFont(myFont);
			dec.setFocusable(false);
			dec.setBackground(new Color(220, 220, 220));
			dec.setMargin(new Insets(0,0,0,0));
			dec.setBorderPainted(false);

			

			hexa.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0){
					hexa.setEnabled(false);
					//setting all other to true enabled
					for(int i = 8 ; i < functionButton.length; i++){
						functionButton[i].setEnabled(true);
					}
					for(int i = 13 ; i < functionButton.length; i++){
						functionButton[i].setEnabled(false);
					}
					
					dec.setEnabled(true);
					octal.setEnabled(true);	
					binary.setEnabled(true);
					dTypeButton[1].setEnabled(false);
					dTypeButton[2].setEnabled(false);
					dTypeButton[3].setEnabled(false);
					dTypeButton[4].setEnabled(false);				
					dTypeButton[5].setEnabled(false);
					
					
					//giving every datatype button default positions
					dTypeButton[0].setEnabled(true);

				}



			});
			hexa.setFont(myFont);
			hexa.setFocusable(false);
			hexa.setBackground(new Color(220, 220, 220));
			hexa.setMargin(new Insets(0,0,0,0));
			hexa.setBorderPainted(false);

			octal.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					
					octal.setEnabled(false);
					//setting alphabets false
					for(int i = 8 ; i < functionButton.length;i++){		
						functionButton[i].setEnabled(false);
					}			
					//setting all the other to true 
					for(int i =0 ; i < numberButton.length-1;i++){
						numberButton[i].setEnabled(true);

					}
					dec.setEnabled(true);
					hexa.setEnabled(true);	
					binary.setEnabled(true);
	
					dTypeButton[1].setEnabled(false);
					dTypeButton[2].setEnabled(false);
					dTypeButton[3].setEnabled(false);
					dTypeButton[5].setEnabled(false);
	
					//disabling number 8 and  9 cause the limit of the octal operator
					numberButton[9].setEnabled(false);
					numberButton[8].setEnabled(false);
		

					//giving every datatype button default positions
					dTypeButton[0].setEnabled(true);
					dTypeButton[4].setEnabled(false);

				}



			});
			octal.setFont(myFont);
			octal.setFocusable(false);
			octal.setBackground(new Color(220, 220, 220));
			octal.setMargin(new Insets(0,0,0,0));
			octal.setBorderPainted(false);

			binary.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					//setting bin button ton false
					binary.setEnabled(false);
					//setting num 2-9 to false
					for(int i =2 ; i < numberButton.length ; i++){		
						numberButton[i].setEnabled(false);
					}

					//setting alphabets to false
					for(int i = 8 ; i < functionButton.length;i++){		
						functionButton[i].setEnabled(false);
						
			
					}
					//setting all the other to true enabled	
					for(int i = 0 ; i < 2 ; i++)	numberButton[i].setEnabled(true);
					dec.setEnabled(true);
					hexa.setEnabled(true);	
					octal.setEnabled(true);

					dTypeButton[1].setEnabled(false);
					dTypeButton[2].setEnabled(false);
					dTypeButton[3].setEnabled(false);
					dTypeButton[5].setEnabled(false);

					//giving every datatype button default positions
					dTypeButton[0].setEnabled(true);
					dTypeButton[4].setEnabled(false);
	
				}

			});
			binary.setFont(myFont);
			binary.setFocusable(false);			
			binary.setBackground(new Color(220, 220, 220));
			binary.setMargin(new Insets(0,0,0,0));
			binary.setBorderPainted(false);

		
			for(int i = 0 ; i < dTypeButton.length; i++){
				dTypeButton[i].setFont(myFont4);
				dTypeButton[i].setFocusable(false);
				dTypeButton[i].setBackground(new Color(220, 220, 220));
				dTypeButton[i].setMargin(new Insets(0,0,0,0));
				dTypeButton[i].setBorderPainted(false);
		
			}

			//Adding action listener to the buttons
			dTypeButton[0].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					
					if(dec.isEnabled()==false){
						dTypeButton[0].setEnabled(false);
						dTypeButton[1].setEnabled(true);
						dTypeButton[2].setEnabled(true);
						dTypeButton[3].setEnabled(true);
						dTypeButton[4].setEnabled(true);
						dTypeButton[5].setEnabled(true);	
					}
					else{
						dTypeButton[0].setEnabled(false);
						dTypeButton[1].setEnabled(false);
						dTypeButton[2].setEnabled(false);
						dTypeButton[3].setEnabled(false);
						dTypeButton[4].setEnabled(false);
						dTypeButton[5].setEnabled(false);

					}
				}
			});

			dTypeButton[1].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					
				
					if(dec.isEnabled()==false){
						dTypeButton[0].setEnabled(true);
						dTypeButton[1].setEnabled(false);
						dTypeButton[2].setEnabled(true);
						dTypeButton[3].setEnabled(true);
						dTypeButton[4].setEnabled(true);
						dTypeButton[5].setEnabled(true);
					}
					else{
						dTypeButton[1].setEnabled(false);
						dTypeButton[2].setEnabled(false);
						dTypeButton[3].setEnabled(false);
						dTypeButton[4].setEnabled(false);
						dTypeButton[5].setEnabled(false);

					}	
				}
			});

			dTypeButton[2].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){

					if(dec.isEnabled()==false){

						dTypeButton[0].setEnabled(true);
						dTypeButton[1].setEnabled(true);
						dTypeButton[2].setEnabled(false);
						dTypeButton[3].setEnabled(true);
						dTypeButton[4].setEnabled(true);
						dTypeButton[5].setEnabled(true);	
					}
						
					else{
						dTypeButton[1].setEnabled(false);
						dTypeButton[2].setEnabled(false);
						dTypeButton[3].setEnabled(false);
						dTypeButton[4].setEnabled(false);
						dTypeButton[5].setEnabled(false);

					}	

				}
			});

			dTypeButton[3].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(dec.isEnabled()==false){

						dTypeButton[0].setEnabled(true);
						dTypeButton[1].setEnabled(true);
						dTypeButton[2].setEnabled(true);
						dTypeButton[3].setEnabled(false);
						dTypeButton[4].setEnabled(true);
						dTypeButton[5].setEnabled(true);	
					}
						
					else{
						dTypeButton[1].setEnabled(false);
						dTypeButton[2].setEnabled(false);
						dTypeButton[3].setEnabled(false);
						dTypeButton[4].setEnabled(false);
						dTypeButton[5].setEnabled(false);

					}	

				}
			});
 
			dTypeButton[4].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(dec.isEnabled()==false){

						dTypeButton[0].setEnabled(true);
						dTypeButton[1].setEnabled(true);
						dTypeButton[2].setEnabled(true);
						dTypeButton[3].setEnabled(true);
						dTypeButton[4].setEnabled(false);
						dTypeButton[5].setEnabled(true);	
					}
						
					else{
						dTypeButton[0].setEnabled(true);
						dTypeButton[1].setEnabled(false);
						dTypeButton[2].setEnabled(false);
						dTypeButton[3].setEnabled(false);
						dTypeButton[4].setEnabled(false);
						dTypeButton[5].setEnabled(false);

					}	

				}
			});

			dTypeButton[5].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					if(dec.isEnabled()==false){

						dTypeButton[0].setEnabled(true);
						dTypeButton[1].setEnabled(true);
						dTypeButton[2].setEnabled(true);
						dTypeButton[3].setEnabled(true);
						dTypeButton[4].setEnabled(true);
						dTypeButton[5].setEnabled(false);	
					}
						
					else{
						dTypeButton[1].setEnabled(false);
						dTypeButton[2].setEnabled(false);
						dTypeButton[3].setEnabled(false);
						dTypeButton[4].setEnabled(false);
						dTypeButton[5].setEnabled(false);

					}	

				}
			});


				


			//creating the function buttons 
			addButton  = new JButton("+");
			subtButton = new JButton("-");
			multiButton= new JButton("*");
			diviButton = new JButton("/");
			decButton  = new JButton(".");
			equalButton= new JButton("=");
			deletButton= new JButton("DEL");
			clearButton= new JButton("CLR");
			a          = new JButton("A");
			b          = new JButton("B");
			c          = new JButton("C");
			d          = new JButton("D");
			e          = new JButton("E");
	
			//further function Buttons
			remButton   = new JButton("REM");
			percButton  = new JButton("%");
			expButton   = new JButton("  { x  }^{ 2  }   ");
			degButton   = new JButton("DEG");
			radButton   = new JButton("RAD");
			sinButton   = new JButton("Sin");
			cosButton   = new JButton("Cos");
			tanButton   = new JButton("Tan");
			invButton   = new JButton("INV");
			hypButton   = new JButton("HYP");
			logButton   = new JButton("Log");
			miscButton	= new	JButton("MISC");
			
			functionButton[0]= addButton;
			functionButton[1]= subtButton;
			functionButton[2]= multiButton;
			functionButton[3]= diviButton;
			functionButton[4]= decButton;
			functionButton[5]= equalButton;
			functionButton[6]= deletButton;
			functionButton[7]= clearButton;
			functionButton[8]= a;
			functionButton[9]= b;
			functionButton[10]=c;
			functionButton[11]=d;
			functionButton[12]=e;
			functionButton[13]= remButton;
			functionButton[14]= percButton;
			functionButton[15]= expButton;
			functionButton[16]= degButton;
			functionButton[17]= radButton;
			functionButton[18]= sinButton;
			functionButton[19]= cosButton;
			functionButton[20]= tanButton;
			functionButton[21]= invButton;
			functionButton[22]= hypButton;
			functionButton[23]= logButton;
			functionButton[24]= miscButton;
	

			

			deletButton.setBounds(200,400,80,25);
			clearButton.setBounds(300,400,80,25);
			deletButton.setBackground(Color.RED);
			clearButton.setBackground(Color.RED);
			for(int i =0; i < 25;i++){
				functionButton[i].addActionListener(this);
				functionButton[i].setFont(myFont);
				functionButton[i].setFocusable(false);
				functionButton[i].setBackground(new Color(220, 220, 220));
				functionButton[i].setMargin(new Insets(0,0,0,0));
				functionButton[i].setBorderPainted(false);
				functionButton[i].setSize(50,50);
		
		
				
				
			}
	
			for(int i = 0; i < 10; i++){
				numberButton[i]=new JButton(String.valueOf(i));
				numberButton[i].addActionListener(this);
				numberButton[i].setFont(myFont2);
				numberButton[i].setFocusable(false);
				numberButton[i].setMargin(new Insets(0,0,0,0));
				numberButton[i].setBackground(new Color(255, 255, 255));
				numberButton[i].setBorderPainted(false);


			}

			functionButton[21].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					functionButton[21].setEnabled(false);
					functionButton[22].setEnabled(true);

					}

			});
			functionButton[22].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					functionButton[22].setEnabled(false);
					functionButton[21].setEnabled(true);

					}

			});

			//panel for numbers and operators
			panel = new JPanel();
			panel.setBounds(140,240,230,230);
			panel.setLayout(new GridLayout(6,6,10,10));
			panel.setBackground(new Color(240,240,240));
			panel.setFont(myFont2);

			panel.add(functionButton[24]);
			panel.add(functionButton[13]);
			panel.add(functionButton[14]);
			panel.add(functionButton[15]);
			panel.add(functionButton[16]);
			panel.add(functionButton[17]);

			panel.add(functionButton[8]);
			panel.add(numberButton[7]);
			panel.add(numberButton[8]);
			panel.add(numberButton[9]);
			panel.add(functionButton[0]);
			panel.add(functionButton[18]);


			panel.add(functionButton[9]);
			panel.add(numberButton[4]);
			panel.add(numberButton[5]);
			panel.add(numberButton[6]);
			panel.add(functionButton[1]);
			panel.add(functionButton[19]);


			panel.add(functionButton[10]);
			panel.add(numberButton[1]);
			panel.add(numberButton[2]);
			panel.add(numberButton[3]);
			panel.add(functionButton[2]);
			panel.add(functionButton[20]);


			panel.add(functionButton[11]);
			panel.add(functionButton[3]);
			panel.add(numberButton[0]);
			panel.add(functionButton[4]);
			panel.add(functionButton[5]);
			panel.add(functionButton[21]);

			panel.add(functionButton[12]);
			panel.add(functionButton[22]);
			panel.add(functionButton[23]);
			// can use some button here panel.add(functionButton[24]);
			panel.add(deletButton);
			panel.add(clearButton);
			

/**			panel.add(functionButton[6]);
			panel.add(functionButton[7]);
*/
			panel2 = new JPanel();
			panel2.setBounds(140,150,230,20);
			panel2.setLayout(new GridLayout(1,4,5,5));
			panel2.setFont(myFont);
			panel2.setBackground(new Color(240,240,240));

			panel2.add(dec);
			panel2.add(hexa);
			panel2.add(octal);
			panel2.add(binary);
			
			panel1 = new JPanel();
			panel1.setBounds(140,200,230,20);
			panel1.setLayout(new GridLayout(1,6,10,10));
			panel1.setBackground(new Color(240,240,240));
			
			for(int i = 0 ; i < dTypeButton.length; i++){
				panel1.add(dTypeButton[i]);	

			}
			deletButton.setFont(myFont);
			clearButton.setFont(myFont);



//			frame.add(deletButton);
//			frame.add(clearButton);
			frame.add(textfield);
			frame.add(panel);	
			frame.add(panel1);
			frame.add(panel2);
			frame.add(panel3);
			frame.setVisible(true);	
			//label.seText("CALCULATOR");
		}

	public static void main(String[] args){
		Calculator calc = new Calculator();	//creating an object of the same class calcuator 

	}

	

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==hexa){

		
		}

		if(dec.isEnabled()==false){
			if(dTypeButton[0].isEnabled()==false){
		

				for(int i = 0; i < 10; i++){
					if(e.getSource()==numberButton[i]){
					textfield.setText(textfield.getText().concat(String.valueOf(i)));
					}
				}
				if(e.getSource()==functionButton[23]){
					textfield.setText("log(");
					operator = 'l';

				}
				if(e.getSource()==functionButton[18]){
					textfield.setText("SIN(");
					//num1ForInt=Integer.parseInt(textfield.getText());
					//trig = textfield.getText();
					//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
					operator = 's';
					
				}
				if(e.getSource()==functionButton[19]){
					textfield.setText("Cos(");
					//num1ForInt=Integer.parseInt(textfield.getText());
					//trig = textfield.getText();
					//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
					operator = 'c';
					
				}
				if(e.getSource()==functionButton[20]){
					textfield.setText("Tan(");
					//num1ForInt=Integer.parseInt(textfield.getText());
					//trig = textfield.getText();
					//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
					operator = 't';
					
				}
				if(functionButton[21].isEnabled()==false){
					if(e.getSource()==functionButton[18]){
						textfield.setText("Csc(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
						operator = '1';
					
					}
					if(e.getSource()==functionButton[19]){
						textfield.setText("Sec(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
						operator = '2';
					
					}
					if(e.getSource()==functionButton[20]){
						textfield.setText("Cot(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
						operator = '3';
						
					}
	
				}
				if(functionButton[22].isEnabled()==false){
					if(e.getSource()==functionButton[18]){
						textfield.setText("(hyp)Sin(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(9,trig.length()-1));
						operator = '4';
					
					}
					if(e.getSource()==functionButton[19]){
						textfield.setText("(hyp)Cos(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(9,trig.length()-1));
						operator = '5';
					
					}
					if(e.getSource()==functionButton[20]){
						textfield.setText("(hyp)Tan(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(9,trig.length()-1));
						operator = '6';
						
					}
	
				}
				if(e.getSource()==functionButton[13]){
					num1ForInt = Integer.parseInt(textfield.getText());
					operator = '%';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[14]){
					num1ForInt = Integer.parseInt(textfield.getText());
					operator = 'p';
					textfield.setText("");
				}

				if(e.getSource()==functionButton[0]){
					num1ForInt = Integer.parseInt(textfield.getText());
					operator = '+';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[1]){
					num1ForInt = Integer.parseInt(textfield.getText());
					operator = '-';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[2]){
					num1ForInt = Integer.parseInt(textfield.getText());
					operator = '*';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[3]){
					num1ForInt = Integer.parseInt(textfield.getText());
					operator = '/';
					textfield.setText("");
				}


				if(e.getSource()==functionButton[5]){
				switch(operator){
					case '+':
						num2ForInt= Integer.parseInt(textfield.getText());
						resultForInt = num1ForInt + num2ForInt;
						textfield.setText(String.valueOf(resultForInt));
						num1ForInt =resultForInt;

						break;
					case '-':
						num2ForInt= Integer.parseInt(textfield.getText());
						resultForInt = num1ForInt - num2ForInt;
						textfield.setText(String.valueOf(resultForInt));
						num1ForInt =resultForInt;

						break;

					case '*':
						num2ForInt= Integer.parseInt(textfield.getText());
						resultForInt = num1ForInt * num2ForInt;
						textfield.setText(String.valueOf(resultForInt));
						num1ForInt =resultForInt;

						break;
					case '/':
						num2ForInt= Integer.parseInt(textfield.getText());
						resultForInt = num1ForInt / num2ForInt;
						textfield.setText(String.valueOf(resultForInt));
						num1ForInt =resultForInt;

						break;
					case '%':
						resultForInt = num1ForInt % num2ForInt;
						textfield.setText(String.valueOf(resultForInt));
						num1ForInt =resultForInt;

						break;
					case 'p':
						resultForInt = (num1ForInt / num2ForInt)*100;
						textfield.setText(String.valueOf(resultForInt)+"%");
						num1ForInt =resultForInt;

						break;

					case 'l':
						trig = textfield.getText();
						modifiedTrig =Integer.parseInt(trig.substring(4,trig.length()-1));
	
						resultForInt =(int) Math.log(modifiedTrig); 
						textfield.setText(String.valueOf(resultForInt));

						break;

					case 's':
						trig = textfield.getText();
						modifiedTrig =Integer.parseInt(trig.substring(4,trig.length()-1));
	
						resultForInt =(int) Math.sin(modifiedTrig); 
						textfield.setText(String.valueOf(resultForInt));

						break;
					case 'c':
						trig = textfield.getText();
						modifiedTrig =Integer.parseInt(trig.substring(4,trig.length()-1));
	
						resultForInt =(int) Math.cos(modifiedTrig); 
						textfield.setText(String.valueOf(resultForInt));

						break;
					case 't':
						trig = textfield.getText();
						modifiedTrig =Integer.parseInt(trig.substring(4,trig.length()-1));
	
						resultForInt =(int) Math.tan(modifiedTrig); 
						textfield.setText(String.valueOf(resultForInt));

						break;
					case '1':
						trig = textfield.getText();
						modifiedTrig =Integer.parseInt(trig.substring(4,trig.length()-1));
	
						resultForInt =(int) Math.asin(modifiedTrig); 
						textfield.setText(String.valueOf(resultForInt));

						break;
					case '2':
						trig = textfield.getText();
						modifiedTrig =Integer.parseInt(trig.substring(4,trig.length()-1));
	
						resultForInt =(int) Math.acos(modifiedTrig); 
						textfield.setText(String.valueOf(resultForInt));

						break;
					case '3':
						trig = textfield.getText();
						modifiedTrig =Integer.parseInt(trig.substring(4,trig.length()-1));
	
						resultForInt =(int) Math.atan(modifiedTrig); 
						textfield.setText(String.valueOf(resultForInt));

						break;
					case '4':
						trig = textfield.getText();
						modifiedTrig =Integer.parseInt(trig.substring(4,trig.length()-1));
	
						resultForInt =(int) Math.sinh(modifiedTrig); 
						textfield.setText(String.valueOf(resultForInt));

						break;
					case '5':
						trig = textfield.getText();
						modifiedTrig =Integer.parseInt(trig.substring(4,trig.length()-1));
	
						resultForInt =(int) Math.cosh(modifiedTrig); 
						textfield.setText(String.valueOf(resultForInt));

						break;
					case '6':
						trig = textfield.getText();
						modifiedTrig =Integer.parseInt(trig.substring(4,trig.length()-1));
	
						resultForInt =(int) Math.tanh(modifiedTrig); 
						textfield.setText(String.valueOf(resultForInt));

						break;

					}
				}

				if(e.getSource()==functionButton[7]){
		 			textfield.setText("");
				}
				if(e.getSource()==functionButton[4]){
					textfield.setText(textfield.getText().concat("."));

				}
				if(e.getSource()==functionButton[6]){
					String fullString= textfield.getText();
					textfield.setText("");
					for(int i = 0; i < fullString.length()-1;i++){
						textfield.setText(textfield.getText()+fullString.charAt(i));
					}		
	
				}
			}
			if(dTypeButton[1].isEnabled()==false){
	
				for(int i = 0; i < 10; i++){
					if(e.getSource()==numberButton[i]){
					textfield.setText(textfield.getText().concat(String.valueOf(i)));
					}
				}
		
				if(e.getSource()==functionButton[0]){
					num1ForLong = Long.parseLong(textfield.getText());
					operator = '+';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[1]){
					num1ForLong = Long.parseLong(textfield.getText());
					operator = '-';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[2]){
					num1ForLong = Long.parseLong(textfield.getText());
					operator = '*';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[3]){
					num1ForLong = Long.parseLong(textfield.getText());
					operator = '/';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[23]){
					textfield.setText("log(");
					operator = 'l';

				}
				if(e.getSource()==functionButton[18]){
					textfield.setText("SIN(");
					//num1ForInt=Integer.parseInt(textfield.getText());
					//trig = textfield.getText();
					//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
					operator = 's';
					
				}
				if(e.getSource()==functionButton[19]){
					textfield.setText("Cos(");
					//num1ForInt=Integer.parseInt(textfield.getText());
					//trig = textfield.getText();
					//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
					operator = 'c';
					
				}
				if(e.getSource()==functionButton[20]){
					textfield.setText("Tan(");
					//num1ForInt=Integer.parseInt(textfield.getText());
					//trig = textfield.getText();
					//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
					operator = 't';
					
				}
				if(functionButton[21].isEnabled()==false){
					if(e.getSource()==functionButton[18]){
						textfield.setText("Csc(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
						operator = '1';
					
					}
					if(e.getSource()==functionButton[19]){
						textfield.setText("Sec(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
						operator = '2';
					
					}
					if(e.getSource()==functionButton[20]){
						textfield.setText("Cot(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(4,trig.length()-1));
						operator = '3';
						
					}
	
				}
				if(functionButton[22].isEnabled()==false){
					if(e.getSource()==functionButton[18]){
						textfield.setText("(hyp)Sin(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(9,trig.length()-1));
						operator = '4';
					
					}
					if(e.getSource()==functionButton[19]){
						textfield.setText("(hyp)Cos(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(9,trig.length()-1));
						operator = '5';
					
					}
					if(e.getSource()==functionButton[20]){
						textfield.setText("(hyp)Tan(");
						//num1ForInt=Integer.parseInt(textfield.getText());
						//trig = textfield.getText();
						//modifiedTrig=Integer.parseInt(trig.substring(9,trig.length()-1));
						operator = '6';
						
					}
	
				}
				if(e.getSource()==functionButton[5]){
				num2ForLong= Long.parseLong(textfield.getText());
				switch(operator){
					case '+':
						resultForLong = num1ForLong + num2ForLong;
						break;
						case '-':
						resultForLong = num1ForLong - num2ForLong;
						break;
					case '*':
						resultForLong = num1ForLong * num2ForLong;
						break;
					case '/':
						resultForLong = num1ForLong / num2ForLong;
						break;

					}
				textfield.setText(String.valueOf(resultForLong));
				num1ForLong =resultForLong;
				}

				if(e.getSource()==functionButton[7]){
		 			textfield.setText("");
				}
				if(e.getSource()==functionButton[4]){
					textfield.setText(textfield.getText().concat("."));

				}
				if(e.getSource()==functionButton[6]){
					String fullString= textfield.getText();
					textfield.setText("");
					for(int i = 0; i < fullString.length()-1;i++){
						textfield.setText(textfield.getText()+fullString.charAt(i));
					}		
	
				}
			}
			if(dTypeButton[2].isEnabled()==false){
	
				for(int i = 0; i < 10; i++){
					if(e.getSource()==numberButton[i]){
					textfield.setText(textfield.getText().concat(String.valueOf(i)));
					}
				}
		
				if(e.getSource()==functionButton[0]){
					num1ForByte = Byte.parseByte(textfield.getText());
					operator = '+';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[1]){
					num1ForByte = Byte.parseByte(textfield.getText());
					operator = '-';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[2]){
					num1ForByte = Byte.parseByte(textfield.getText());
					operator = '*';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[3]){
					num1ForByte = Byte.parseByte(textfield.getText());
					operator = '/';
					textfield.setText("");
				}

				if(e.getSource()==functionButton[5]){
				num2ForByte= Byte.parseByte(textfield.getText());
				switch(operator){
					case '+':
						resultForByte =(byte)( num1ForByte + num2ForByte);
						break;
						case '-':
						resultForByte =(byte)(  num1ForByte - num2ForByte);
						break;
					case '*':
						resultForByte =(byte)(  num1ForByte * num2ForByte);
						break;
					case '/':
						resultForByte =(byte)(  num1ForByte / num2ForByte);
						break;
					}
				textfield.setText(String.valueOf(resultForByte));
				num1ForByte =resultForByte;
				}

				if(e.getSource()==functionButton[7]){
		 			textfield.setText("");
				}
				if(e.getSource()==functionButton[4]){
					textfield.setText(textfield.getText().concat("."));

				}
				if(e.getSource()==functionButton[6]){
					String fullString= textfield.getText();
					textfield.setText("");
					for(int i = 0; i < fullString.length()-1;i++){
						textfield.setText(textfield.getText()+fullString.charAt(i));
					}		
	
				}
			}
			if(dTypeButton[3].isEnabled()==false){
	
				for(int i = 0; i < 10; i++){
					if(e.getSource()==numberButton[i]){
					textfield.setText(textfield.getText().concat(String.valueOf(i)));
					}
				}
		
				if(e.getSource()==functionButton[0]){
					num1ForShort = Short.parseShort(textfield.getText());
					operator = '+';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[1]){
					num1ForShort = Short.parseShort(textfield.getText());
					operator = '-';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[2]){
					num1ForShort = Short.parseShort(textfield.getText());
					operator = '*';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[3]){
					num1ForShort = Short.parseShort(textfield.getText());
					operator = '/';
					textfield.setText("");
				}

				if(e.getSource()==functionButton[5]){
				num2ForShort= Short.parseShort(textfield.getText());
				switch(operator){
					case '+':
						resultForShort =(short)( num1ForShort + num2ForShort);
						break;
						case '-':
						resultForShort =(short)( num1ForShort - num2ForShort);
						break;
					case '*':
						resultForShort =(short)( num1ForShort * num2ForShort);
						break;
					case '/':
						resultForShort =(short)( num1ForShort / num2ForShort);
						break;
					}
				textfield.setText(String.valueOf(resultForShort));
				num1ForShort =resultForShort;
				}

				if(e.getSource()==functionButton[7]){
		 			textfield.setText("");
				}
				if(e.getSource()==functionButton[4]){
					textfield.setText(textfield.getText().concat("."));

				}
				if(e.getSource()==functionButton[6]){
					String fullString= textfield.getText();
					textfield.setText("");
					for(int i = 0; i < fullString.length()-1;i++){
						textfield.setText(textfield.getText()+fullString.charAt(i));
					}		
	
				}
			}
			if(dTypeButton[4].isEnabled()==false){
	
				for(int i = 0; i < 10; i++){
					if(e.getSource()==numberButton[i]){
					textfield.setText(textfield.getText().concat(String.valueOf(i)));
					}
				}
		
				if(e.getSource()==functionButton[0]){
					num1ForFloat = Float.parseFloat(textfield.getText());
					operator = '+';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[1]){
					num1ForFloat = Float.parseFloat(textfield.getText());
					operator = '-';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[2]){
					num1ForFloat = Float.parseFloat(textfield.getText());
					operator = '*';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[3]){
					num1ForFloat = Float.parseFloat(textfield.getText());
					operator = '/';
					textfield.setText("");
				}

				if(e.getSource()==functionButton[5]){
				num2ForFloat= Float.parseFloat(textfield.getText());
				switch(operator){
					case '+':
						resultForFloat = num1ForFloat + num2ForFloat;
						break;
						case '-':
						resultForFloat = num1ForFloat - num2ForFloat;
						break;
					case '*':
						resultForFloat = num1ForFloat * num2ForFloat;
						break;
					case '/':
						resultForFloat = num1ForFloat / num2ForFloat;
						break;

					}
				textfield.setText(String.valueOf(resultForFloat));
				num1ForFloat =resultForFloat;
				}

				if(e.getSource()==functionButton[7]){
		 			textfield.setText("");
				}
				if(e.getSource()==functionButton[4]){
					textfield.setText(textfield.getText().concat("."));

				}
				if(e.getSource()==functionButton[6]){
					String fullString= textfield.getText();
					textfield.setText("");
					for(int i = 0; i < fullString.length()-1;i++){
						textfield.setText(textfield.getText()+fullString.charAt(i));
					}		
	
				}
			}
			if(dTypeButton[5].isEnabled()==false){
	
				for(int i = 0; i < 10; i++){
					if(e.getSource()==numberButton[i]){
					textfield.setText(textfield.getText().concat(String.valueOf(i)));
					}
				}
		
				if(e.getSource()==functionButton[0]){
					num1ForDouble = Double.parseDouble(textfield.getText());
					operator = '+';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[1]){
					num1ForDouble = Double.parseDouble(textfield.getText());
					operator = '-';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[2]){
					num1ForDouble = Double.parseDouble(textfield.getText());
					operator = '*';
					textfield.setText("");
				}
				if(e.getSource()==functionButton[3]){
					num1ForDouble = Double.parseDouble(textfield.getText());
					operator = '/';
					textfield.setText("");
				}

				if(e.getSource()==functionButton[5]){
				num2ForDouble= Double.parseDouble(textfield.getText());
				switch(operator){
					case '+':
						resultForDouble = num1ForDouble + num2ForDouble;
						break;
						case '-':
						resultForDouble = num1ForDouble - num2ForDouble;
						break;
					case '*':
						resultForDouble = num1ForDouble * num2ForDouble;
						break;
					case '/':
						resultForDouble = num1ForDouble / num2ForDouble;
						break;

					}
				textfield.setText(String.valueOf(resultForDouble));
				num1ForDouble =resultForDouble;
				}

				if(e.getSource()==functionButton[7]){
		 			textfield.setText("");
				}
				if(e.getSource()==functionButton[4]){
					textfield.setText(textfield.getText().concat("."));

				}
				if(e.getSource()==functionButton[6]){
					String fullString= textfield.getText();
					textfield.setText("");
					for(int i = 0; i < fullString.length()-1;i++){
						textfield.setText(textfield.getText()+fullString.charAt(i));
					}		
	
				}
			}
		}
		//action listener for hexadecimal
		if(hexa.isEnabled()==false){
			if(dTypeButton[0].isEnabled()==false){
				
				

				for(int i = 0 ; i < 10 ; i++){
		     			if(e.getSource()==numberButton[i]){
						textfield.setText(textfield.getText().concat(String.valueOf(i)));
					}
				}
			
				for(int i =8 ; i < 13 ; i++){
					if(e.getSource()==functionButton[i]){
						if(i == 8)
						textfield.setText(textfield.getText().concat("A"));
						if(i == 9)
						textfield.setText(textfield.getText().concat("B"));
						if(i == 10)
						textfield.setText(textfield.getText().concat("C"));
						if(i == 11)
						textfield.setText(textfield.getText().concat("D"));
						if(i == 12)
						textfield.setText(textfield.getText().concat("E"));

					}

				}
				
				for(int i =0 ; i < 4;i++){
					if(e.getSource()==functionButton[i]){
						num1forHexa =textfield.getText(); //Integer.parseInt(textfield.getText());
						textfield.setText("");
						if(i==0) operator='+';
						if(i==1) operator='-';
						if(i==2) operator='*';
						if(i==3) operator='/';

					}
				}

				if(e.getSource()==functionButton[5]){
					num2forHexa=textfield.getText(); //Integer.parseInt(textfield.getText());
					textfield.setText("");

					switch(operator){
						case '+':{
							resultforHexa =Integer.toHexString(Integer.parseInt(num1forHexa,16)+Integer.parseInt(num2forHexa,16));
							//String dj = resultforHexa;
							//System.out.println(dj);
							textfield.setText(String.valueOf(resultforHexa.toUpperCase()));
							break;
						}
						
						case '-':{
							diff = 0;
							subtHexa = Integer.parseInt(num1forHexa,16) - Integer.parseInt(num2forHexa,16);
							if(subtHexa<0){
								subtHexa=(-1)*subtHexa;
								diff = 1; 
								
							}
							resultforHexa =Integer.toHexString(subtHexa);
							if(diff==1){
								resultforHexa="-"+resultforHexa;
							}
							textfield.setText(resultforHexa);							
							break;	
						}
				
						case '*':{
							resultforHexa= Integer.toHexString(Integer.parseInt(num1forHexa,16)*Integer.parseInt(num2forHexa,16));
							textfield.setText(resultforHexa.toUpperCase());
							break;
						}
						
						case '/':{
							resultforHexa=Integer.toHexString(Integer.parseInt(num1forHexa,16) / Integer.parseInt(num2forHexa,16));
							textfield.setText(resultforHexa.toUpperCase());
							break;

						}



					}

				}
				if(e.getSource()==functionButton[7]){
					textfield.setText("");
			
				}


			}

		}
		if(octal.isEnabled()==false){
			if(dTypeButton[0].isEnabled()==false){
				
				

				for(int i = 0 ; i < 9 ; i++){
		     			if(e.getSource()==numberButton[i]){
						textfield.setText(textfield.getText().concat(String.valueOf(i)));
					}
				}
			
		
				for(int i =0 ; i < 4;i++){
					if(e.getSource()==functionButton[i]){
						num1forOct =textfield.getText(); //Integer.parseInt(textfield.getText());
						textfield.setText("");
						if(i==0) operator='+';
						if(i==1) operator='-';
						if(i==2) operator='*';
						if(i==3) operator='/';

					}
				}

				if(e.getSource()==functionButton[5]){
					num2forOct=textfield.getText(); //Integer.parseInt(textfield.getText());
					textfield.setText("");

					switch(operator){
						case '+':{
							resultforOct =Integer.toOctalString(Integer.parseInt(num1forOct,8)+Integer.parseInt(num2forOct,8));
							//String dj = resultforHexa;
							//System.out.println(dj);
							textfield.setText(String.valueOf(resultforOct.toUpperCase()));
							break;
						}
						
						case '-':{
							diff1 = 0;
							subtOct = Integer.parseInt(num1forOct,8) - Integer.parseInt(num2forOct,8);
							if(subtOct<0){
								subtOct=(-1)*subtOct;
								diff1 = 1; 
								
							}
							resultforOct =Integer.toOctalString(subtOct);
							if(diff==1){
								resultforOct="-"+resultforOct;
							}
							textfield.setText(resultforOct);							
							break;	
						}
				
						case '*':{
							resultforOct= Integer.toOctalString(Integer.parseInt(num1forOct,8)*Integer.parseInt(num2forOct,8));
							textfield.setText(resultforOct.toUpperCase());
							break;
						}
						
						case '/':{
							resultforOct=Integer.toOctalString(Integer.parseInt(num1forOct,8) / Integer.parseInt(num2forOct,8));
							textfield.setText(resultforOct.toUpperCase());
							break;

						}



					}

				}
				if(e.getSource()==functionButton[7]){
					textfield.setText("");
			
				}


			}

		}
		if(binary.isEnabled()==false){
			if(dTypeButton[0].isEnabled()==false){
				
				

				for(int i = 0 ; i < 2 ; i++){
		     			if(e.getSource()==numberButton[i]){
						textfield.setText(textfield.getText().concat(String.valueOf(i)));
					}
				}
			
		
				for(int i =0 ; i < 4;i++){
					if(e.getSource()==functionButton[i]){
						num1forBin =textfield.getText(); //Integer.parseInt(textfield.getText());
						textfield.setText("");
						if(i==0) operator='+';
						if(i==1) operator='-';
						if(i==2) operator='*';
						if(i==3) operator='/';

					}
				}

				if(e.getSource()==functionButton[5]){
					num2forBin=textfield.getText(); //Integer.parseInt(textfield.getText());
					textfield.setText("");

					switch(operator){
						case '+':{
							resultforBin =Integer.toBinaryString(Integer.parseInt(num1forBin,2)+Integer.parseInt(num2forBin,2));
							//String dj = resultforHexa;
							//System.out.println(dj);
							textfield.setText(String.valueOf(resultforBin.toUpperCase()));
							break;
						}
						
						case '-':{
							diff1 = 0;
							subtBin = Integer.parseInt(num1forBin,2) - Integer.parseInt(num2forBin,2);
							if(subtBin<0){
								subtBin=(-1)*subtBin;
								diff1 = 1; 
								
							}
							resultforBin =Integer.toBinaryString(subtBin);
							if(diff==1){
								resultforBin="-"+resultforBin;
							}
							textfield.setText(resultforBin);							
							break;	
						}
				
						case '*':{
							resultforBin= Integer.toBinaryString(Integer.parseInt(num1forBin,2)*Integer.parseInt(num2forBin,2));
							textfield.setText(resultforBin.toUpperCase());
							break;
						}
						
						case '/':{
							resultforBin=Integer.toBinaryString(Integer.parseInt(num1forBin,2) / Integer.parseInt(num2forBin,2));
							textfield.setText(resultforBin.toUpperCase());
							break;

						}



					}

				}
				if(e.getSource()==functionButton[7]){
					textfield.setText("");
			
				}


			}

		}			
			

	}
	


}