import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Calculator implements ActionListener{
		JFrame frame = new JFrame();	//creating an object of the class JFrame
		JLabel label = new JLabel();	//creating an object of the class JLabel
		JButton[] numberButton= new JButton[10];	//creating an array of object of the class JButton
		JButton[] functionButton=new JButton[13];
		JTextField textfield;
		JButton addButton , multiButton, subtButton, diviButton;
		JButton decButton, equalButton, deletButton, clearButton; 
		JPanel panel, panel2, panel3;
		
		//mode buttons
		JButton dec, hexa, octal, binary;

		//Alphabets buttons
		JButton  a , b ,c, d ,e;

		Font myFont = new Font("Times New Roman",Font.BOLD,10);
		Font myFont2 = new Font("Times New Roman",Font.BOLD,15);
		Font myFont3 = new Font("Times New Roman",Font.BOLD,25);

		int num1 =0;
		int num2= 0;
		int result= 0; 
		char operator;
		
		Calculator(){		//adding an constructor which is called upon creation of the object of the class
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(500,500);
			frame.setResizable(false);
			frame.setLayout(null);
			frame.setTitle("CALCULATOR");
			frame.getContentPane().setBackground(Color.BLACK);
			
			textfield = new JTextField();
			textfield.setBounds(80,25,300,50);
			textfield.setEditable(false);
			textfield.setBackground(Color.YELLOW);
			textfield.setFont(myFont3);
		
			//creating the mode buttons
			dec = new JButton("DEC");
			hexa = new JButton("HEXA");
			octal = new JButton("OCT");
			binary = new JButton("BIN");
		
			dec.addActionListener(this);
			dec.setFont(myFont);
			dec.setFocusable(false);

			hexa.addActionListener(this);
			hexa.setFont(myFont);
			hexa.setFocusable(false);

			octal.addActionListener(this);
			octal.setFont(myFont);
			octal.setFocusable(false);

			binary.addActionListener(this);
			binary.setFont(myFont);
			binary.setFocusable(false);			

			//creating the function buttons 
			addButton  = new JButton("+");
			subtButton = new JButton("-");
			multiButton= new JButton("*");
			diviButton = new JButton("/");
			decButton  = new JButton(".");
			equalButton= new JButton("=");
			deletButton= new JButton("DELETE");
			clearButton= new JButton("CLEAR");
			a          = new JButton("A");
			b          = new JButton("B");
			c          = new JButton("C");
			d          = new JButton("D");
			e          = new JButton("E");

			functionButton[0]= addButton;
			functionButton[1]= subtButton;
			functionButton[2]= multiButton;
			functionButton[3]= diviButton;
			functionButton[4]= decButton;
			functionButton[5]= equalButton;
			functionButton[6]= deletButton;
			functionButton[7]= clearButton;
			functionButton[8]= a;
			functionButton[9]= b;
			functionButton[10]= c;
			functionButton[11]= d;
			functionButton[12]= e;

			deletButton.setBounds(200,400,80,25);
			clearButton.setBounds(300,400,80,25);
			deletButton.setBackground(Color.RED);
			clearButton.setBackground(Color.RED);
			for(int i =0; i < 13;i++){
				functionButton[i].addActionListener(this);
				functionButton[i].setFont(myFont2);
				functionButton[i].setFocusable(false);
				functionButton[i].setBackground(Color.WHITE);
				
				
			}
	
			for(int i = 0; i < 10; i++){
				numberButton[i]=new JButton(String.valueOf(i));
				numberButton[i].addActionListener(this);
				numberButton[i].setFont(myFont2);
				numberButton[i].setFocusable(false);
			}
			//panel for numbers and operators
			panel = new JPanel();
			panel.setBounds(140,190,250,250);
			panel.setLayout(new GridLayout(5,5,5,5));
			panel.setBackground(Color.BLACK);
			panel.setFont(myFont2);

			panel.add(functionButton[8]);
			panel.add(numberButton[7]);
			panel.add(numberButton[8]);
			panel.add(numberButton[9]);
			panel.add(functionButton[0]);

			panel.add(functionButton[9]);
			panel.add(numberButton[4]);
			panel.add(numberButton[5]);
			panel.add(numberButton[6]);
			panel.add(functionButton[1]);

			panel.add(functionButton[10]);
			panel.add(numberButton[1]);
			panel.add(numberButton[2]);
			panel.add(numberButton[3]);
			panel.add(functionButton[2]);
			

			panel.add(functionButton[11]);
			panel.add(functionButton[3]);
			panel.add(numberButton[0]);
			panel.add(functionButton[4]);
			panel.add(functionButton[5]);
			panel.add(functionButton[12]);

/**			panel.add(functionButton[6]);
			panel.add(functionButton[7]);

*/
			panel2 = new JPanel();
			panel2.setBounds(100,100,300,50);
			panel2.setLayout(new GridLayout(1,4,5,5));
			panel2.setFont(myFont);

			panel2.add(dec);
			panel2.add(hexa);
			panel2.add(octal);
			panel2.add(binary);
	
		
			deletButton.setFont(myFont);
			clearButton.setFont(myFont);



			frame.add(deletButton);
			frame.add(clearButton);
			frame.add(textfield);
			frame.add(panel);
			frame.add(panel2);
			frame.setVisible(true);	
			//label.seText("CALCULATOR");
		}

	public static void main(String[] args){
		Calculator calc = new Calculator();	//creating an object of the same class calcuator 
		

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==hexa){

		
		}


		if(e.getSource()==dec){ 
		functionButton[8].setEditable(false);
		for(int i = 0; i < 10; i++){
			if(e.getSource()==numberButton[i]){
				textfield.setText(textfield.getText().concat(String.valueOf(i)));
			}
		}
		
		if(e.getSource()==functionButton[0]){
			num1 = Integer.parseInt(textfield.getText());
			operator = '+';
			textfield.setText("");
		}
		if(e.getSource()==functionButton[1]){
			num1 = Integer.parseInt(textfield.getText());
			operator = '-';
			textfield.setText("");
		}
		if(e.getSource()==functionButton[2]){
			num1 = Integer.parseInt(textfield.getText());
			operator = '*';
			textfield.setText("");
		}
		if(e.getSource()==functionButton[3]){
			num1 = Integer.parseInt(textfield.getText());
			operator = '/';
			textfield.setText("");
		}

		if(e.getSource()==functionButton[5]){
			num2= Integer.parseInt(textfield.getText());
			switch(operator){
				case '+':
					result = num1 + num2;
					break;
				case '-':
					result = num1 - num2;
					break;
				case '*':
					result = num1 * num2;
					break;
				case '/':
					result = num1 / num2;
					break;

			}
			textfield.setText(String.valueOf(result));
			num1 =result;
		}

		if(e.getSource()==functionButton[7]){
		 	textfield.setText("");
		}
		if(e.getSource()==functionButton[4]){
			textfield.setText(textfield.getText().concat("."));

		}
		if(e.getSource()==functionButton[6]){
			String fullString= textfield.getText();
			textfield.setText("");
			for(int i = 0; i < fullString.length()-1;i++){
				textfield.setText(textfield.getText()+fullString.charAt(i));
			}		
	
		}
		}
     }
/**
	public int void addition(int num1,num2 ){
		int total = num1 + num2;
		}
	public int void subtract(int num1,num2 ){
		int total = num1 - num2;
		}
	public int void multiply(int num1,num2 ){
		int total = num1 * num2;
		}
	public int void division(int num1,num2 ){
		int total = num1 / num2;
		}
*/

}