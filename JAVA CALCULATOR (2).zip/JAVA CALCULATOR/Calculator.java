import javax.swing.border.TitledBorder;
import javax.swing.border.Border;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
//import Buttons.*;

public class Calculator implements ActionListener {

	
		JFrame frame = new JFrame();	//creating an object of the class JFrame
		JLabel label = new JLabel();	//creating an object of the class JLabel
		JButton[] numberButton= new JButton[10];	//creating an array of object of the class JButton
		JButton[] functionButton=new JButton[25];
		JTextField textfield;

		JButton addButton , multiButton, subtButton, diviButton;
		JButton decButton, equalButton, deletButton, clearButton;
		JButton remButton, percButton, expButton, degButton, radButton, miscButton;
		JButton sinButton, cosButton, tanButton, invButton, hypButton,logButton;
		JButton intButton, fltButton, bytButton, shtButton, lngButton,dblButton;


		JPanel panel, panel2, panel3;
		
		//mode buttons
		JButton dec, hexa, octal, binary;

		//Alphabets buttons
		JButton  a , b ,c, d ,e;

		Font myFont = new Font("Times New Roman",Font.BOLD,10);
		Font myFont2 = new Font("Times New Roman",Font.BOLD,15);
		Font myFont3 = new Font("Times New Roman",Font.BOLD,25);

		int num1 =0;
		int num2= 0;
		int result= 0; 
		char operator;
		
		Calculator(){		//adding an constructor which is called upon creation of the object of the class
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setSize(550,580);
			frame.setResizable(false);
			frame.setLayout(null);
			frame.setTitle("CALCULATOR");
			frame.getContentPane().setBackground(Color.WHITE);
			
			panel3 = new JPanel();
			panel3.setBackground(new Color(245,245,245));
			panel3.setBounds(120,10,270,500);
			Border blackline = BorderFactory.createLineBorder(new Color(0,0,0,8),4);
			panel3.setBorder(blackline);
		
			
			textfield = new JTextField();
			textfield.setBounds(140,50,230,50);
			textfield.setEditable(false);
			textfield.setBackground(new Color(255, 255, 255));
			textfield.setFont(myFont3);
		
			//creating the mode buttons
			dec = new JButton("DEC");
			hexa = new JButton("HEXA");
			octal = new JButton("OCT");
			binary = new JButton("BIN");
		
			dec.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0){
					dec.setEnabled(false);
					for(int i = 8 ; i < functionButton.length; i++){
						functionButton[i].setEnabled(false);
					}
					//setting all the other the other things to true
					for(int i = 0 ; i < numberButton.length ; i++){
						numberButton[i].setEnabled(true);
					}
					hexa.setEnabled(true);
					octal.setEnabled(true);	
					binary.setEnabled(true);				
				}
			});

			dec.setFont(myFont);
			dec.setFocusable(false);
			dec.setBackground(new Color(220, 220, 220));
			dec.setMargin(new Insets(0,0,0,0));
			dec.setBorderPainted(false);

			

			hexa.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0){
					hexa.setEnabled(false);
					//setting all other to true enabled
					for(int i = 8 ; i < functionButton.length; i++){
						functionButton[i].setEnabled(true);
					}
					
					dec.setEnabled(true);
					octal.setEnabled(true);	
					binary.setEnabled(true);
					
				
				}



			});
			hexa.setFont(myFont);
			hexa.setFocusable(false);
			hexa.setBackground(new Color(220, 220, 220));
			hexa.setMargin(new Insets(0,0,0,0));
			hexa.setBorderPainted(false);

			octal.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					
					octal.setEnabled(false);
					//setting alphabets false
					for(int i = 8 ; i < functionButton.length;i++){		
						functionButton[i].setEnabled(false);
					}			
					//setting all the other to true 
					for(int i =0 ; i < numberButton.length-1;i++){
						numberButton[i].setEnabled(true);

					}
					dec.setEnabled(true);
					hexa.setEnabled(true);	
					binary.setEnabled(true);
	

					//disabling number 9
					numberButton[9].setEnabled(false);		
				}



			});
			octal.setFont(myFont);
			octal.setFocusable(false);
			octal.setBackground(new Color(220, 220, 220));
			octal.setMargin(new Insets(0,0,0,0));
			octal.setBorderPainted(false);

			binary.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					//setting bin button ton false
					binary.setEnabled(false);
					//setting num 2-9 to false
					for(int i =2 ; i < numberButton.length ; i++){		
						numberButton[i].setEnabled(false);
					}

					//setting alphabets to false
					for(int i = 8 ; i < functionButton.length;i++){		
						functionButton[i].setEnabled(false);
						
			
					}
					//setting all the other to true enabled	
					for(int i = 0 ; i < 2 ; i++)	numberButton[i].setEnabled(true);
					dec.setEnabled(true);
					hexa.setEnabled(true);	
					octal.setEnabled(true);

		
				}

			});
			binary.setFont(myFont);
			binary.setFocusable(false);			
			binary.setBackground(new Color(220, 220, 220));
			binary.setMargin(new Insets(0,0,0,0));
			binary.setBorderPainted(false);

			//creating 
			


			//creating the function buttons 
			addButton  = new JButton("+");
			subtButton = new JButton("-");
			multiButton= new JButton("*");
			diviButton = new JButton("/");
			decButton  = new JButton(".");
			equalButton= new JButton("=");
			deletButton= new JButton("DELETE");
			clearButton= new JButton("CLEAR");
			a          = new JButton("A");
			b          = new JButton("B");
			c          = new JButton("C");
			d          = new JButton("D");
			e          = new JButton("E");
	
			//further function Buttons
			remButton   = new JButton("REM");
			percButton  = new JButton("%");
			expButton   = new JButton("  { x  }^{ 2  }   ");
			degButton   = new JButton("DEG");
			radButton   = new JButton("RAD");
			sinButton   = new JButton("Sin");
			cosButton   = new JButton("Cos");
			tanButton   = new JButton("Tan");
			invButton   = new JButton("INV");
			hypButton   = new JButton("HYP");
			logButton   = new JButton("Log");
			miscButton	= new	JButton("MISC");
			
			functionButton[0]= addButton;
			functionButton[1]= subtButton;
			functionButton[2]= multiButton;
			functionButton[3]= diviButton;
			functionButton[4]= decButton;
			functionButton[5]= equalButton;
			functionButton[6]= deletButton;
			functionButton[7]= clearButton;
			functionButton[8]= a;
			functionButton[9]= b;
			functionButton[10]=c;
			functionButton[11]=d;
			functionButton[12]=e;
			functionButton[13]= remButton;
			functionButton[14]= percButton;
			functionButton[15]= expButton;
			functionButton[16]= degButton;
			functionButton[17]= radButton;
			functionButton[18]= sinButton;
			functionButton[19]= cosButton;
			functionButton[20]= tanButton;
			functionButton[21]= invButton;
			functionButton[22]= hypButton;
			functionButton[23]= logButton;
			functionButton[24]= miscButton;
	

			

			deletButton.setBounds(200,400,80,25);
			clearButton.setBounds(300,400,80,25);
			deletButton.setBackground(Color.RED);
			clearButton.setBackground(Color.RED);
			for(int i =0; i < 25;i++){
				functionButton[i].addActionListener(this);
				functionButton[i].setFont(myFont);
				functionButton[i].setFocusable(false);
				functionButton[i].setBackground(new Color(220, 220, 220));
				functionButton[i].setMargin(new Insets(0,0,0,0));
				functionButton[i].setBorderPainted(false);
		
		
				
				
			}
	
			for(int i = 0; i < 10; i++){
				numberButton[i]=new JButton(String.valueOf(i));
				numberButton[i].addActionListener(this);
				numberButton[i].setFont(myFont2);
				numberButton[i].setFocusable(false);
				numberButton[i].setMargin(new Insets(0,0,0,0));
				numberButton[i].setBackground(new Color(255, 255, 255));
				numberButton[i].setBorderPainted(false);


			}

			//panel for numbers and operators
			panel = new JPanel();
			panel.setBounds(140,240,230,230);
			panel.setLayout(new GridLayout(6,6,10,10));
			panel.setBackground(new Color(240,240,240));
			panel.setFont(myFont2);

			panel.add(functionButton[24]);
			panel.add(functionButton[13]);
			panel.add(functionButton[14]);
			panel.add(functionButton[15]);
			panel.add(functionButton[16]);
			panel.add(functionButton[17]);

			panel.add(functionButton[8]);
			panel.add(numberButton[7]);
			panel.add(numberButton[8]);
			panel.add(numberButton[9]);
			panel.add(functionButton[0]);
			panel.add(functionButton[18]);


			panel.add(functionButton[9]);
			panel.add(numberButton[4]);
			panel.add(numberButton[5]);
			panel.add(numberButton[6]);
			panel.add(functionButton[1]);
			panel.add(functionButton[19]);


			panel.add(functionButton[10]);
			panel.add(numberButton[1]);
			panel.add(numberButton[2]);
			panel.add(numberButton[3]);
			panel.add(functionButton[2]);
			panel.add(functionButton[20]);


			panel.add(functionButton[11]);
			panel.add(functionButton[3]);
			panel.add(numberButton[0]);
			panel.add(functionButton[4]);
			panel.add(functionButton[5]);
			panel.add(functionButton[21]);

			panel.add(functionButton[12]);
			panel.add(functionButton[22]);
			panel.add(functionButton[23]);
			// can use some button here panel.add(functionButton[24]);
			panel.add(deletButton);
			panel.add(clearButton);
			

/**			panel.add(functionButton[6]);
			panel.add(functionButton[7]);
*/
			panel2 = new JPanel();
			panel2.setBounds(140,150,230,20);
			panel2.setLayout(new GridLayout(1,4,5,5));
			panel2.setFont(myFont);
			panel2.setBackground(new Color(240,240,240));

			panel2.add(dec);
			panel2.add(hexa);
			panel2.add(octal);
			panel2.add(binary);
	
		
			deletButton.setFont(myFont);
			clearButton.setFont(myFont);



//			frame.add(deletButton);
//			frame.add(clearButton);
			frame.add(textfield);
			frame.add(panel);
			frame.add(panel2);
			frame.add(panel3);
			frame.setVisible(true);	
			//label.seText("CALCULATOR");
		}

	public static void main(String[] args){
		Calculator calc = new Calculator();	//creating an object of the same class calcuator 

	}

	

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==hexa){

		
		}

		if(dec.isEnabled()==false){
		//if(e.getActionCommand()=="DEC"){ 
		//functionButton[8].setEditable(false);
		for(int i = 0; i < 10; i++){
			if(e.getSource()==numberButton[i]){
				textfield.setText(textfield.getText().concat(String.valueOf(i)));
			}
		}
		
		if(e.getSource()==functionButton[0]){
			num1 = Integer.parseInt(textfield.getText());
			operator = '+';
			textfield.setText("");
		}
		if(e.getSource()==functionButton[1]){
			num1 = Integer.parseInt(textfield.getText());
			operator = '-';
			textfield.setText("");
		}
		if(e.getSource()==functionButton[2]){
			num1 = Integer.parseInt(textfield.getText());
			operator = '*';
			textfield.setText("");
		}
		if(e.getSource()==functionButton[3]){
			num1 = Integer.parseInt(textfield.getText());
			operator = '/';
			textfield.setText("");
		}

		if(e.getSource()==functionButton[5]){
			num2= Integer.parseInt(textfield.getText());
			switch(operator){
				case '+':
					result = num1 + num2;
					break;
				case '-':
					result = num1 - num2;
					break;
				case '*':
					result = num1 * num2;
					break;
				case '/':
					result = num1 / num2;
					break;

			}
			textfield.setText(String.valueOf(result));
			num1 =result;
		}

		if(e.getSource()==functionButton[7]){
		 	textfield.setText("");
		}
		if(e.getSource()==functionButton[4]){
			textfield.setText(textfield.getText().concat("."));

		}
		if(e.getSource()==functionButton[6]){
			String fullString= textfield.getText();
			textfield.setText("");
			for(int i = 0; i < fullString.length()-1;i++){
				textfield.setText(textfield.getText()+fullString.charAt(i));
			}		
	
		}
		}


}
	
/**
	public int void addition(int num1,num2 ){
		int total = num1 + num2;
		}
	public int void subtract(int num1,num2 ){
		int total = num1 - num2;
		}
	public int void multiply(int num1,num2 ){
		int total = num1 * num2;
		}
	public int void division(int num1,num2 ){
		int total = num1 / num2;
		}
*/

}